import dataloader
import os  
import argparse
import random
import numpy as np
import torch as th
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from model import UniST_model
from utils import add_dict_to_argparser, str2bool
from Embed import DataEmbedding
from train import TrainLoop
from torch.utils.tensorboard import SummaryWriter


def setup_init(seed):  
    #random.seed()	固定 Python 内置随机函数
    #np.random.seed()	固定 Numpy 的随机性
    #torch.manual_seed()	固定 PyTorch 的 CPU 随机性
    #torch.cuda.manual_seed()	固定 GPU 上的随机性
    #PYTHONHASHSEED	固定 Python 的哈希值顺序（间接影响迭代顺序）
    #cudnn.deterministic=True	让 CUDA 使用确定性算法（但会慢）
    #udnn.benchmark=False	禁用优化搜索路径，进一步保证结果稳定
    
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    th.manual_seed(seed)
    th.cuda.manual_seed(seed)
    th.backends.cudnn.benchmark = False
    th.backends.cudnn.deterministic = True

def create_argparser():
    defaults = dict(
        # experimental settings
        add_train_model = None,
        add_train_ephoch = 100,
        task = 'short',
        dataset = 'FY4A_multiareas',
        mode='training', # ['training','prompting','testing','resume_training']
        file_load_path = '',
        used_data = '',
        process_name = 'process_name',
        prompt_ST = 0,
        his_len = 4,
        pred_len = 4,
        few_ratio = 0.5,
        stage = 1,

        # model settings
        mask_ratio = 0.5,
        #这个是用于embed的patch_size 此处为t*h*w 为2*2*2的patch
        patch_size = 16,
        t_patch_size = 2,
        #随时可以调节的源代码
        size = 'middle',
        #
        no_qkv_bias = 0,
        pos_emb = 'SinCos',
        num_memory_spatial = 512,
        num_memory_temporal = 512,
        conv_num = 3,
        prompt_content = 's_p_c',

        # pretrain settings
        random=True,
        mask_strategy = 'random', # ['random','causal','frame','tube']
        mask_strategy_random = 'batch', # ['none','batch']
        
        # training parameters
        lr=1e-3,
        min_lr = 1e-5,
        early_stop = 5,
        weight_decay=1e-6,
        batch_size=256,
        log_interval=10,
        total_epoches = 300,
        device_id='0,1',
        machine = 'machine_name',
        clip_grad = 0.05,
        lr_anneal_steps = 200,
        batch_size_1 = 64,
        batch_size_2 = 32,
        batch_size_3 = 16,
    )
    parser = argparse.ArgumentParser()
    add_dict_to_argparser(parser, defaults)
    return parser


def dev(device_ids='0'):
    if th.cuda.is_available():
        return th.device(f'cuda:{device_ids.split(",")[0]}')  # 主设备
    return th.device("cpu")

def main():
    #创造一个种子
    setup_init(100)
    #创建参数
    args = create_argparser().parse_args()
    #这个要设置文件夹，可以删
    os.chdir('/home/tensor/ganzheyu/UniST/SeaST')
    train_data,val_data,test_data,args.scaler= dataloader.data_load('./dataset/{}'.format(args.dataset),args)
    
    if(args.mode=='training'):
        args.folder = 'training'+args.dataset
    else:
        args.folder = 'testing'+args.dataset
    #log保存路径
    #tensorboard --logdir=logs --port=6007
    #http://localhost:6007/
    #ssh -L 6007:localhost:6007 username@server_ip
    logdir = "./logs/{}".format(args.folder)
    writer = SummaryWriter(log_dir = logdir,flush_secs=5)
    #模型保存路径
    args.model_path = './experiments/{}'.format(args.folder)
    #绑定device实现分布式训练 device_ids = '0,1,2,3'
    device_ids = args.device_id.split(',')
    device = dev(args.device_id)
    #创建一个 UniST_model 此处逻辑为判断是否需要加训
    model = UniST_model(args=args)
    if(args.add_train_model!=None):
        checkpoint = th.load(args.add_train_model, map_location='cuda')
        if 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
        else:
            model.load_state_dict(checkpoint)
        args.total_epoches = args.add_train_ephoch
    #分布式训练
    if len(device_ids) > 1 and th.cuda.device_count() > 1:
        print(f"Using {len(device_ids)} GPUs: {device_ids}")
        model = nn.DataParallel(model, device_ids=[int(i) for i in device_ids])
    model.to(device)
    
    TrainLoop(
        args = args,
        model=model,
        writer=writer,
        data=train_data,
        test_data=test_data, 
        val_data=val_data,
        device=device,
        early_stop = args.early_stop,
    ).run_loop()
    
if __name__ == "__main__":
    main()
    