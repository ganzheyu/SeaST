import numpy as np
import os
import sys

# 1. 加载原始 train.npy 文件
train_path = "train.npy"
train_data = np.load(train_path)  # 假设格式为 (B, T, C, H, W)

print(train_data.shape)

# 2. 打乱索引
num_samples = train_data.shape[0]
indices = np.random.permutation(num_samples)

# 3. 按照 90% / 10% 划分
split_idx = int(num_samples * 0.9)
train_indices = indices[:split_idx]
val_indices = indices[split_idx:]

# 4. 划分数据
new_train_data = train_data[train_indices]
val_data = train_data[val_indices]

# 5. 保存文件
np.save("train.npy", new_train_data)
np.save("val.npy", val_data)
print(new_train_data.shape)
print(val_data.shape)

print(f"划分完成：train.npy -> {new_train_data.shape}, val.npy -> {val_data.shape}")
