import numpy as np
import torch as th
from torch.utils.data import Dataset, DataLoader , TensorDataset
import os

class MinMaxNormalization(object):
    def __init__(self):
        pass

    def fit(self, X):
        self._min = X.min()
        self._max = X.max()
        print("min:", self._min, "max:", self._max)

    def transform(self, X):
        X = 1. * (X - self._min) / (self._max - self._min)
        X = X * 2. - 1.
        return X

    def fit_transform(self, X):
        self.fit(X)
        return self.transform(X)

    def inverse_transform(self, X):
        X = (X + 1.) / 2.
        X = 1. * X * (self._max - self._min) + self._min
        return X

def data_load(folder_path,args):
    # 加载 .npy 数据
    train_path = os.path.join(folder_path, 'train.npy')
    val_path = os.path.join(folder_path, 'val.npy')
    test_path = os.path.join(folder_path, 'test.npy')

    train_data = np.load(train_path)
    val_data = np.load(val_path)
    test_data = np.load(test_path)
    
    print(train_data.shape)
    print(val_data.shape)
    print(test_data.shape)

    scaler = MinMaxNormalization()
    
    scaler.fit(train_data)
    scaler.fit(val_data)
    scaler.fit(test_data)
    train_data = scaler.transform(train_data)
    val_data = scaler.transform(val_data)
    test_data = scaler.transform(test_data)

    train_tensor = th.tensor(train_data, dtype=th.float32)
    val_tensor = th.tensor(val_data, dtype=th.float32)
    test_tensor = th.tensor(test_data, dtype=th.float32)
    
    train_loader = DataLoader(TensorDataset(train_tensor), batch_size=args.batch_size_1, shuffle=True)
    val_loader = DataLoader(TensorDataset(val_tensor), batch_size=args.batch_size_1, shuffle=False)
    test_loader = DataLoader(TensorDataset(test_tensor), batch_size=args.batch_size_1, shuffle=False)

    return train_loader, val_loader, test_loader, scaler
    
